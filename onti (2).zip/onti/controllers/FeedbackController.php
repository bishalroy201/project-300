<?php
require_once('Controller.php');
require_once(__DIR__ .'/../models/Feedback.php');

class FeedbackController extends Controller
{
    public function index()
    {
        $users = Feedback::all();
        
        return $users;
    }

    public function create($array)
    {
        $users = Feedback::create($array);
        
        return 'Your Feedback Successfully Submitted';
    }
}
