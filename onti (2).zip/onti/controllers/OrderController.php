<?php
require_once('Controller.php');
require_once(__DIR__ .'/../models/Order.php');

class OrderController extends Controller
{  
    public function index()
    {
        $orders = Order::all();
        
        return $orders;  
    }

    public function store($array)
    {
        $orders = Order::store($array);
        
        return 'Order Have Been Created';
    }
  
}
