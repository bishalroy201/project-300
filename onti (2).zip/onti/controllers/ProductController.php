<?php
require_once('Controller.php');
require_once(__DIR__ .'/../models/Product.php');

class ProductController extends Controller
{  
    public function index()
    {
        $products = Product::all();
        
        return $products;  
    }

    public function show($id)
    {
        $product = Product::find($id);
        
        return $product;
    }

    public function store($array)
    {
        $products = Product::store($array);
        
        return 'Product Have Been Created';
    }

    public function edit($id)
    {
        $this->viewWith('product_edit', $id);
    }

    public function update($array, $id)
    {
        $product = Product::update($array, $id);
        if($product)
            return "Product Successfully Updated!!!";
    }

    public function destroy($id)
    {
        Product::destroy($id);

        $this->view('product_index');
    }

    public function getCategories()
    {
        $categories = Product::raw('SELECT DISTINCT category FROM products');

        return $categories;
    }

    public function getProductListByCategory($category)
    {
        $products = Product::raw("SELECT * FROM products where category = '$category' ");

        return $products;
    }

    
    
}
