<?php

require_once 'controllers/LoginController.php';

$err_uname = '';
$err_pass = '';
$err_invalid = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST['username'];
    $password = $_POST['password'];
    $utype = $_POST['utype'];

    $flag = true;

    if (empty($username)) {
        $err_uname = "*username is required";
        $flag = false;
    }

    if (empty($password)) {
        $err_pass = "*password is required";
        $flag = false;
    }

    if ($flag) {
        $login = new LoginController;
        $log = $login->validate($username, $password, $utype);
        
        $err_invalid = $log;
        
    }
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index Page</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-primary">
            <ul class="nav-item">
                <li><a href="">Home</a></li>
                <li><a href="views/about.php">About Us</a></li>
                <li><a href="views/registration.php">Registration</a></li>
                <li><a href="views/feedback.php">Feedback</a></li>
                <li><a href="views/contact.php">Contact Us</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-3">

            <fieldset>
                <legend>Login</legend>
                <form method="post" action="">
                    <br>
                    <label for="utype">User Type</label>
                    <select id="utype" name="utype">
                        <option value="user">User</option>
                        <option value="employee">Employee</option>
                        <option value="admin">Admin</option>
                    </select><br>
                    <small class="text-danger"> <?=$err_invalid?> </small><br><br>
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username"><br>
                    <small class="text-danger"> <?=$err_uname?> </small><br><br>

                    <label for="password">Password</label>
                    <input type="password" id="password" name="password"><br>
                    <small class="text-danger"> <?=$err_pass?> </small><br><br>

                    <input class="btn btn-primary" type="submit" value="Login">
                </form>
            </fieldset>

        </div>
        <div class="col-6">
            <h2 class="text-center">Welcome to Our Website</h2>
            <p>
                Lorem ipsum carrots enhanced rebates. The pain of life will unfold in them will open no distinction
                between the consequences of the choice of the labor of some things that condemn, that the said, in the
                time of pleasures often rejecting it, however, from the! Him. Lorem ipsum carrots enhanced rebates. In
                the time of the matter: for he may repel the choice of the architect is to ask, nor, criticized the
                error of the righteous: the blandishments of these symptoms, they are, while we were hates the whole,
                provides, and the agony of the pain. Lorem ipsum carrots enhanced rebates. Denounce choices required to
                achieve one or the ways we provide in mind. Those who praise with canticles, the flattery of her hatred
                than desire for the existence of a too must have this much pain.
            </p>

            <p>
                Lorem ipsum carrots enhanced rebates. The pain of life will unfold in them will open no distinction
                between the consequences of the choice of the labor of some things that condemn, that the said, in the
                time of pleasures often rejecting it, however, from the! Him. Lorem ipsum carrots enhanced rebates. In
                the time of the matter: for he may repel the choice of the architect is to ask, nor, criticized the
                error of the righteous: the blandishments of these symptoms, they are, while we were hates the whole,
                provides, and the agony of the pain. Lorem ipsum carrots enhanced rebates. Denounce choices required to
                achieve one or the ways we provide in mind. Those who praise with canticles, the flattery of her hatred
                than desire for the existence of a too must have this much pain.
            </p>
        </div>
    </div>

    <footer class="footer-fixed">
        <p>Footer</p>
    </footer>
</body>

</html>