<?php
require_once 'Model.php';

class Employee extends Model
{
    protected static $table_name = "employees";
}
