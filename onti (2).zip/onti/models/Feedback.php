<?php
require_once 'Model.php';

class Feedback extends Model
{
    protected static $table_name = "feedbacks";
}
