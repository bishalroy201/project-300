<?php

class Model 
{
    protected static $table_name = "";
    protected static $servername = "localhost";
    protected static $dbname = "rms";
    protected static $username = "root";
    protected static $password = '';

    function __construct()
    {
        
    }

    public static function all()
    {
        $conn = mysqli_connect(self::$servername, self::$username, self::$password, self::$dbname);
        
        $query = "SELECT * FROM ".static::$table_name;
    
        $result = mysqli_query($conn,$query);

        $conn->close(); 
        
        $rows = [];

        while($row = mysqli_fetch_assoc($result)) {
            $rows[] = (object)$row;
        }

        if(count($rows) > 0)
        {
            return $rows;
        }else{
            return null;
        }
        
    }

    public static function find($id)
    {
        $conn = mysqli_connect(self::$servername, self::$username, self::$password, self::$dbname);
        
        $query = "SELECT * FROM " . static::$table_name . " WHERE id = $id";

        $result = mysqli_query($conn,$query);

        $conn->close();  
        
        $rows = [];

        while($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }

        if(count($rows) > 0)
        {
            return (object) $rows[0];
        }else{
            return null;
        }
        
    }

    public static function raw($query)
    {
        $conn = mysqli_connect(self::$servername, self::$username, self::$password, self::$dbname);

        $result = mysqli_query($conn,$query);

        $conn->close();  
        
        $rows = [];

        while($row = mysqli_fetch_assoc($result)) {
            $rows[] = (object) $row;
        }

        if(count($rows) > 0)
        {
            return $rows;
        }else{
            return null;
        }
        
    }

    public static function store($array)
    {
        $conn = mysqli_connect(self::$servername, self::$username, self::$password, self::$dbname);
        
        $query = "INSERT INTO " . static::$table_name . " (";
        $flag = false;
        foreach($array as  $key => $value)
        {
            $query .= $key . ' ,';
        }

        $query = rtrim($query, ',');
        $query.=') values (';

        foreach ($array as $key => $value) {
            $query .= "'".$value . "' ,";
        }

        $query = rtrim($query, ',');
        $query.=') ';

        if (mysqli_query($conn, $query)) {
            $flag = true;
        } else {
            return "Error: " . $query . "<br>" . mysqli_error($conn);
        }
        
        mysqli_close($conn);  
        
        return $flag;
    }

    public static function update($array, $id)
    {
        $conn = mysqli_connect(self::$servername, self::$username, self::$password, self::$dbname);
        
        $query = "UPDATE " . static::$table_name . " SET ";
        $flag = false;
        foreach($array as  $key => $value)
        {
            $query .= $key . " = '$value' ,";
        }

        $query = rtrim($query, ',');
        $query.=" WHERE id = $id";
       
        if (mysqli_query($conn, $query)) {
            $flag = true;
        } else {
            return "Error: " . $query . "<br>" . mysqli_error($conn);
        }
        
        mysqli_close($conn);  
        
        return $flag;
    }

    public static function destroy($id)
    {
        $conn = mysqli_connect(self::$servername, self::$username, self::$password, self::$dbname);
        
        $query = "DELETE FROM " . static::$table_name . " WHERE id=$id;";

        if (mysqli_query($conn, $query)) {
            $flag = true;
        } else {
            return "Error: " . $query . "<br>" . mysqli_error($conn);
        }
        
        mysqli_close($conn);  
        
        return $flag;
    }
}