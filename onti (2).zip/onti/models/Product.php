<?php
require_once 'Model.php';

class Product extends Model
{
    protected static $table_name = "products";
}
