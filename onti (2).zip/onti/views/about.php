<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index Page</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-primary">
            <ul class="nav-item">
                <li><a href="../index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="registration.php">Registration</a></li>
                <li><a href="feedback.php">Feedback</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-3"></div>
        <div class="col-4 text-center">
            <fieldset>
                <legend>About Us</legend>
                <!-- Type here -->
            </fieldset>
        </div>
        <div class="col-3"></div>
    </div>

<footer class="footer-fixed">
        <p>This Project Developed By Foysol Ahmed Id : 17-34507-2</p>
    </footer>
</body>

</html>