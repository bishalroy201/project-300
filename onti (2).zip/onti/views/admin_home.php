<?php
session_start();

if (!isset($_SESSION["utype"]) or $_SESSION["utype"] != 'admin') {
    header("Location: ../index.php");
}
require_once __DIR__ . '/../controllers/FeedbackController.php';

$feedbackController = new FeedbackController;
$feedbacks = $feedbackController->index();

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index Page</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-admin">
            <ul class="nav-item">
                <li><a href="admin_home.php">Home</a></li>
                <li><a href="user_index.php">User Panel</a></li>
                <li><a href="staff_index.php">Staff Panel</a></li>
                <li><a href="product_index.php">Product Panel</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-2"></div>
        <div class="col-3 text-center">
            <h2 class="text-secondary">Welcome, <?php echo $_SESSION["username"] ?></h2>
            <hr>
            <h1 class="text-secondary">Feedback</h1>
            <table>
                <tr>
                    <th>Name</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>Message/Query</th>
                </tr>
                <?php
                    foreach ($feedbacks as $feedback) {
                        echo "<tr> ";
                        echo "<td>$feedback->name</td>";
                        echo "<td>$feedback->contact</td>";
                        echo "<td>$feedback->email</td>";
                        echo "<td>$feedback->message</td>";
                        echo "</tr>";
                    }
                ?>
            </table>
        </div>
        <div class="col-2"></div>
    </div>

    <footer class="footer-fixed bg-admin">
        <p>Footer</p>
    </footer>
</body>

</html>