<?php
session_start();

if (!isset($_SESSION["utype"]) or $_SESSION["utype"] != 'admin') {
    header("Location: ../index.php");
}

require_once __DIR__ . '/../controllers/EmployeeController.php';

$errs = [];
$username = $password = $name = $contact = $salary = '';
$success = '';

if(isset($_GET['id']))
{
    $employeeController = new EmployeeController;
    $user = $employeeController->show($_GET['id']);

    $name = $user->name;
    $contact = $user->contact;
    $salary = $user->salary;
    $gender = $user->gender;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $contact = $_POST['contact'];
   
    $salary = $_POST['salary'];

    if (empty($name)) {
        $errs[] = "*name is required";
    }

    if (empty($contact)) {
        $errs[] = "*contact is required";
    }

    if (empty($salary)) {
        $errs[] = "*salary is required";
    }

    if (count($errs) == 0) {
        $User = new EmployeeController;
        $datas = [
            
            'name' => $name,
            'gender' => $gender,
            'contact' => $contact,
            'salary' => $salary
        ];
        $flag = $User->update($datas, $_GET['id']);

        $success = $flag;
    }
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Edit Page</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-admin">
            <ul class="nav-item">
                <li><a href="admin_home.php">Home</a></li>
                <li><a href="user_index.php">User Panel</a></li>
                <li><a href="staff_index.php">Staff Panel</a></li>
                <li><a href="product_index.php">Product Panel</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-3"></div>
        <div class="col-4">

            <fieldset>
                <legend>Update Staff</legend>

                <form method="post" action="">

                    <?php if (!empty($success)) {?>
                    <div class="alert alert-success">
                        <?=$success?> <br>
                    </div>
                    <?php }?>

                    <?php if (count($errs) > 0) {?>
                    <div class="alert alert-danger">
                        <?php foreach ($errs as $err) {?>
                        <?=$err?> <br>
                        <?php }?>
                    </div>
                    <?php }?>

                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" value="<?=$name?>"><br>

                    <label for="gender">Gender</label>
                    <select id="gender" name="gender">
                        <option value="male"  <?php echo $gender == 'male' ? "selected" : ' ' ?> >Male</option>
                        <option value="female"  <?php echo $gender == 'female' ? 'selected' : ' ' ?> >Female</option>
                    </select><br>

                    <label for="contact">Contact</label>
                    <input type="number" id="contact" name="contact" value="<?=$contact?>"><br>

                    <label for="salary">salary</label>
                    <textarea id="salary" name="salary" rows="4" cols="50"> <?=$salary?> </textarea>


                    <input class="btn btn-primary" type="submit" value="Update">
                </form>
            </fieldset>

        </div>
        <div class="col-3"></div>

    </div>

    <div class="footer-space"></div>
    <footer class="footer-fixed bg-admin">
        <p>Footer</p>
    </footer>
</body>

</html>