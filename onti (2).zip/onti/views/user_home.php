<?php
session_start();

if (!isset($_SESSION["utype"]) or $_SESSION["utype"] != 'user') {
    header("Location: ../index.php");
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Home</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-primary">
            <ul class="nav-item">
                <li><a href="user_home.php">Home</a></li>
                <li><a href="user_menu.php">Menu</a></li>
                <li><a href="online_booking.php">Online Booking</a></li>
                <li><a href="check_status.php">Check Status</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-2"></div>
        <div class="col-4 text-center">
            <h1 class="text-secondary">Welcome, <?=$_SESSION['username']?></h1>
            <hr>
            <h2>Welcome to our website</h2>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque illo necessitatibus blanditiis quam voluptas
            mollitia dolore magnam dolor vel, culpa amet totam repellendus, veniam, placeat consectetur asperiores autem
            omnis enim! Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque illo necessitatibus blanditiis
            quam voluptas
            mollitia dolore magnam dolor vel, culpa amet totam repellendus, veniam, placeat consectetur asperiores autem
            omnis enim!Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque illo necessitatibus blanditiis
            quam voluptas
            mollitia dolore magnam dolor vel, culpa amet totam repellendus, veniam, placeat consectetur asperiores autem
            omnis enim!Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque illo necessitatibus blanditiis
            quam voluptas
            mollitia dolore magnam dolor vel, culpa amet totam repellendus, veniam, placeat consectetur asperiores autem
            omnis enim!Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque illo necessitatibus blanditiis
            quam voluptas
            mollitia dolore magnam dolor vel, culpa amet totam repellendus, veniam, placeat consectetur asperiores autem
            omnis enim!
        </div>
        <div class="col-2"></div>
    </div>

    <div class="footer-space"></div>
    <footer class="footer-fixed bg-primary">
        <p>Footer</p>
    </footer>
</body>

</html>