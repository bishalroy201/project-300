<?php
session_start();

if (!isset($_SESSION["utype"]) or $_SESSION["utype"] != 'admin') {
    header("Location: ../index.php");
}

require_once __DIR__ . '/../controllers/UserController.php';

$userController = new UserController;
$users = $userController->index();

if(isset($_GET['userid']))
{
   if($_GET['method'] == 'edit')
   {
        $userController->edit($_GET['userid']);
   }
   else if($_GET['method'] == 'delete')
   {
        $userController->destroy($_GET['userid']);
   }  
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index Page</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="../assets/css/style.css"></script>
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>

</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-admin">
            <ul class="nav-item">
                <li><a href="admin_home.php">Home</a></li>
                <li><a href="user_index.php">User Panel</a></li>
                <li><a href="staff_index.php">Staff Panel</a></li>
                <li><a href="product_index.php">Product Panel</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-2"></div>
        <div class="col-5 text-center">
           
            <h1 class="text-secondary">Users</h1>
            <!-- <a href="user_create.php" class="btn btn-primary">Create New User</a> <br> <br> -->
            <table>
                <tr>
                    <th>Username</th>
                    <th>Name</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Actions</th>
                </tr>
                <?php

                    if($users)
                    {
                        foreach ($users as $user) {
                            echo "<tr> ";
                            echo "<td>$user->username</td>";
                            echo "<td>$user->name</td>";
                            echo "<td>$user->contact</td>";
                            echo "<td>$user->email</td>";
                            echo "<td>$user->gender</td>";
                            echo "<td>";
                            echo "<button class='btn btn-success' onclick='userEdit($user->id)'>Edit</button>";
                            echo "<button class='btn btn-danger' onclick='userDelete($user->id)'>Delete</button>";         
                            echo "</td>"; 
                            echo "</tr>";
                        }
                    }
           
                ?>
            </table>
        </div>
        <div class="col-2"></div>
    </div>

    <div class="footer-space"></div>
    <footer class="footer-fixed bg-admin">
        <p>Footer</p>
    </footer>
    <script>
    function userDelete(id) {
        var r = confirm("Are You Sure Your Want to Delete This User?");
        if (r == true) {
            window.location.href = `user_index.php?userid=${id}&method=delete`;
        } 
    }

    function userEdit(id) {
        window.location.href = `user_index.php?userid=${id}&method=edit`;
    }
    </script>
</body>

</html>