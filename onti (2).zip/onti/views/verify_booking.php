<?php
session_start();

if (!isset($_SESSION["utype"]) or $_SESSION["utype"] != 'employee') {
    header("Location: ../index.php");
}

require_once __DIR__ . '/../controllers/BookingController.php';

$bookingController = new BookingController;

$success = $danger = '';

if (isset($_GET['bookid'])) {
    if ($_GET['status'] == 'allow') {
        $bookingController->update([
            'status' => 'allowed',
        ], $_GET['bookid']);
        $success = "Booking Successfully Allowed";
    } else if ($_GET['status'] == 'reject') {
        $bookingController->update([
            'status' => 'rejected',
        ], $_GET['bookid']);
        $danger = "Booking Successfully Rejected";
    }
}

$bookingController = new BookingController;
$bookings = $bookingController->FindByStatus('processing');

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Home</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-employee">
            <ul class="nav-item">
                <li><a href="employee_home.php">Home</a></li>
                <li><a href="billing.php">Billing</a></li>
                <li><a href="verify_booking.php">Verify Booking</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-2"></div>
        <div class="col-5 text-center">

            <h1 class="text-secondary">Bookings</h1>
            <!-- <a href="user_create.php" class="btn btn-primary">Create New User</a> <br> <br> -->
            <?php if (!empty($success)) {?>
            <div class="alert alert-success">
                <?=$success?> <br>
            </div>
            <?php }?>

            <?php if (!empty($danger)) {?>
            <div class="alert alert-danger">    
                <?=$danger?> <br>
            </div>
            <?php }?>

            <table>
                <tr>
                    <th>Username</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Table No</th>
                    <th>Seats</th>
                    <th>Set Status</th>
                </tr>
                <?php

                    if ($bookings) {
                        foreach ($bookings as $booking) {
                            echo "<tr> ";
                            echo "<td>$booking->username</td>";
                            echo "<td>$booking->date</td>";
                            echo "<td>$booking->time_from to $booking->time_to</td>";
                            echo "<td>$booking->table_no</td>";
                            echo "<td>$booking->seats</td>";

                            echo "<td>";
                            echo "<button class='btn btn-success' onclick='bookingAllow($booking->id)'>Allow</button>";
                            echo "<button class='btn btn-danger' onclick='bookingReject($booking->id)'>Reject</button>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    }

                ?>
            </table>
        </div>
        <div class="col-2"></div>
    </div>

    <div class="footer-space"></div>
    <footer class="footer-fixed bg-employee">
        <p>Footer</p>
    </footer>
    <script>
    function bookingReject(id) {
        var r = confirm("Are You Sure Your Want to Reject This Booking?");
        if (r == true) {
            window.location.href = `verify_booking.php?bookid=${id}&status=reject`;
        }
    }

    function bookingAllow(id) {
        window.location.href = `verify_booking.php?bookid=${id}&status=allow`;
    }
    </script>
</body>

</html>